package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// iOS-style Light Theme Palette
val IosLightBackground = Color(0xFFF2F2F7)
val IosLightCard = Color(0xFFFFFFFF)
val IosLightSurfaceVariant = Color(0xFFE5E5EA)
val IosLightTextPrimary = Color(0xFF000000)
val IosLightTextSecondary = Color(0xFF6C6C70)
val IosLightDivider = Color(0xFFE5E5EA)
val IosLightBorder = Color(0xFFD1D1D6)

// iOS-style Dark Theme Palette
val IosDarkBackground = Color(0xFF000000)
val IosDarkCard = Color(0xFF1C1C1E)
val IosDarkSurfaceVariant = Color(0xFF2C2C2E)
val IosDarkTextPrimary = Color(0xFFFFFFFF)
val IosDarkTextSecondary = Color(0xFF8E8E93)
val IosDarkDivider = Color(0xFF38383A)
val IosDarkBorder = Color(0xFF38383A)

// Captain Aytos Primary Brand Color
val AytosBlue = Color(0xFF0A84FF)
val AytosBlueDark = Color(0xFF0066CC)
val AytosBlueLightBg = Color(0xFFE5F1FF)

// Judgment Verdict Colors specified by user
val AytosGreen = Color(0xFF34C759)
val AytosGreenBg = Color(0xFFE8F9ED)

val AytosLightGreen = Color(0xFFA3E635)
val AytosLightGreenBg = Color(0xFFF3FBDD)

val AytosOrange = Color(0xFFFF9500)
val AytosOrangeBg = Color(0xFFFFF3E0)

val AytosRed = Color(0xFFFF3B30)
val AytosRedBg = Color(0xFFFFE9E7)

val AytosGray = Color(0xFF8E8E93)
val AytosGrayBg = Color(0xFFF2F2F7)

// Brand Accents for Apps
val UberBlack = Color(0xFF000000)
val DidiOrange = Color(0xFFFF7D00)
val IndriveGreen = Color(0xFF28C76F)
