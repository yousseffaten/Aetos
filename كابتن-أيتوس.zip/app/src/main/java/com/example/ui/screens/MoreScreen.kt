package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.LicenseInfo
import com.example.model.LicenseTier
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun MoreScreen(
    licenseInfo: LicenseInfo,
    onActivateLicense: (String) -> Boolean,
    onTransferDevice: () -> Boolean,
    onSubmitReport: (category: String, description: String, metrics: String) -> Unit,
    onOpenSetupWizard: () -> Unit
) {
    val context = LocalContext.current
    var showReportDialog by remember { mutableStateOf(false) }
    var showLicenseDialog by remember { mutableStateOf(false) }
    var showTransparencyDialog by remember { mutableStateOf(false) }
    var showCommitmentsDialog by remember { mutableStateOf(false) }
    var showPrivacyDialog by remember { mutableStateOf(false) }

    var actionFeedback by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        SectionHeader(
            title = "حسابي والخدمات",
            subtitle = "الاشتراكات، الدعم الفني، والتزامات الخصوصية والأمان"
        )

        // License & Subscription Card
        IosCard {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(AytosBlueLightBg),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.WorkspacePremium,
                            contentDescription = null,
                            tint = AytosBlue,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Column {
                        Text(
                            text = licenseInfo.tier.labelArabic,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = if (licenseInfo.tier == LicenseTier.TRIAL) {
                                "متبقي ${licenseInfo.trialDaysRemaining} أيام في التجربة المجانية"
                            } else if (licenseInfo.tier == LicenseTier.FREE_BASIC) {
                                "حكم الكروت بلا حدود + تحليلين يومياً"
                            } else {
                                "اشتراك شهري مفعل بنجاح ✓"
                            },
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = AytosGreenBg
                ) {
                    Text(
                        text = "نشط",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = AytosGreen,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { showLicenseDialog = true },
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = AytosBlue),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("إدارة الاشتراك / كود الترخيص", fontSize = 12.sp)
                }

                OutlinedButton(
                    onClick = {
                        val success = onTransferDevice()
                        actionFeedback = if (success) {
                            "تم نقل الرخصة لهذا الجهاز بنجاح (متاح مرة واحدة شهرياً)"
                        } else {
                            "عذراً، لقد استهلكت عملية نقل الجهاز لهذا الشهر بالفعل."
                        }
                    },
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("نقل لموبايل جديد", fontSize = 12.sp)
                }
            }
        }

        actionFeedback?.let { msg ->
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = AytosBlueLightBg,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = msg,
                    fontSize = 12.sp,
                    color = AytosBlueDark,
                    modifier = Modifier.padding(10.dp)
                )
            }
        }

        // Section: Setup & Support
        IosCard {
            Text(
                text = "الإعدادات والدعم",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(8.dp))

            MenuItemRow(
                icon = Icons.Default.SettingsAccessibility,
                title = "إعادة تشغيل معالج الإعداد والأذونات",
                subtitle = "الوصول، البطارية، والظهور فوق الشاشة",
                onClick = onOpenSetupWizard
            )
            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))

            MenuItemRow(
                icon = Icons.Default.ReportProblem,
                title = "بلّغ عن مشكلة في قراءة كارت",
                subtitle = "إرسال أرقام الكارت المقروءة دون نصوص شخصية",
                onClick = { showReportDialog = true }
            )
        }

        // Section: Transparency & Commitments
        IosCard {
            Text(
                text = "الشفافية وأمان السائق",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(8.dp))

            MenuItemRow(
                icon = Icons.Default.Security,
                title = "التزامات كابتن أيتوس",
                subtitle = "لا نضغط، لا نتفاوض نيابة عنك، القرار قرارك أنت",
                onClick = { showCommitmentsDialog = true }
            )
            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))

            MenuItemRow(
                icon = Icons.Default.Visibility,
                title = "بيقرا إيه من الشاشة؟",
                subtitle = "قائمة دقيقة بجميع الحقول المقروءة فقط",
                onClick = { showTransparencyDialog = true }
            )
            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))

            MenuItemRow(
                icon = Icons.Default.PrivacyTip,
                title = "سياسة الخصوصية وطلب حذف البيانات",
                subtitle = "معالجة على الموبايل بدون حفظ صور أو نصوص",
                onClick = { showPrivacyDialog = true }
            )
        }

        // Section: Community & Social Channels
        IosCard {
            Text(
                text = "قنوات التواصل ومجتمع الكباتن",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                SocialChannelButton("واتساب", Icons.Default.Chat) {
                    openUrl(context, "https://wa.me/201012345678")
                }
                SocialChannelButton("تيليجرام", Icons.Default.Send) {
                    openUrl(context, "https://t.me/AytosCaptain")
                }
                SocialChannelButton("فيسبوك", Icons.Default.ThumbUp) {
                    openUrl(context, "https://facebook.com/AytosCaptain")
                }
                SocialChannelButton("يوتيوب", Icons.Default.VideoLibrary) {
                    openUrl(context, "https://youtube.com/@AytosCaptain")
                }
                SocialChannelButton("تيك توك", Icons.Default.Movie) {
                    openUrl(context, "https://tiktok.com/@AytosCaptain")
                }
            }
        }

        // About app & version
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = "كابتن أيتوس - الإصدار 1.0.0",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.secondary
            )
            Text(
                text = "صُمم باحترافية لدعم سائقي النقل الذكي في مصر والوطن العربي",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.secondary
            )
        }

        Spacer(modifier = Modifier.height(30.dp))
    }

    // Report Dialog
    if (showReportDialog) {
        ReportProblemDialog(
            onDismiss = { showReportDialog = false },
            onSubmit = { category, desc ->
                onSubmitReport(category, desc, "{\"app\":\"Uber\",\"metricsOnly\":true}")
                showReportDialog = false
                actionFeedback = "شكراً لك يا كابتن! تم تسجيل البلاغ وسيتم تحسين خوارزمية القراءة في التحديث القادم."
            }
        )
    }

    // License & Subscription Dialog
    if (showLicenseDialog) {
        LicenseActivationDialog(
            currentLicense = licenseInfo,
            onDismiss = { showLicenseDialog = false },
            onActivate = { key ->
                val ok = onActivateLicense(key)
                if (ok) {
                    showLicenseDialog = false
                    actionFeedback = "تم تفعيل الاشتراك الشهري بنجاح!"
                }
            }
        )
    }

    // Commitments Dialog
    if (showCommitmentsDialog) {
        AlertDialog(
            onDismissRequest = { showCommitmentsDialog = false },
            title = { Text("التزامات كابتن أيتوس") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("1. التطبيق أداة مساعدة للقراءة والتحليل الحسابي فقط.", fontSize = 13.sp)
                    Text("2. لا يضغط على أي زر نيابة عنك في أوبر أو ديدي أو إن درايف.", fontSize = 13.sp)
                    Text("3. لا يقبل ولا يرفض ولا يفاوض الركاب بدلاً منك.", fontSize = 13.sp)
                    Text("4. لا يحفظ صور الشاشة ولا يسجل مكالماتك أو رسائلك.", fontSize = 13.sp)
                    Text("5. القرار النهائي في قبول أي رحلة أو رفضها يعود لك أنت وحدك كقائد للسيارة.", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            },
            confirmButton = {
                TextButton(onClick = { showCommitmentsDialog = false }) { Text("تم") }
            }
        )
    }

    // Transparency Dialog
    if (showTransparencyDialog) {
        AlertDialog(
            onDismissRequest = { showTransparencyDialog = false },
            title = { Text("ماذا يقرأ التطبيق من الشاشة؟") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("لقطع الشك باليقين، يقرأ كابتن أيتوس الأرقام التالية فقط من كروت أوبر وديدي وإن درايف:", fontSize = 13.sp)
                    Text("• السعر الإجمالي للأجرة (مثلاً 65 ج.م)", fontSize = 12.sp, color = AytosBlue)
                    Text("• مسافة الاستلام ووقت الوصول (مثلاً 1.5 كم)", fontSize = 12.sp, color = AytosBlue)
                    Text("• مسافة الرحلة من الخريطة (مثلاً 12 كم)", fontSize = 12.sp, color = AytosBlue)
                    Text("• تقييم الراكب وعدد رحلاته (مثلاً 4.9 ★)", fontSize = 12.sp, color = AytosBlue)
                    Text("• طريقة الدفع (كاش / فيزا / محفظة)", fontSize = 12.sp, color = AytosBlue)
                    Text("• عدد المحطات وملاحظة الراكب لاكتشاف الكلمات المحظورة.", fontSize = 12.sp, color = AytosBlue)
                    Text("• لا يقرأ ولا يحفظ اسم الراكب أو رقم هاتفه مطلقاً.", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = AytosGreen)
                }
            },
            confirmButton = {
                TextButton(onClick = { showTransparencyDialog = false }) { Text("فهمت ذلك") }
            }
        )
    }

    // Privacy Dialog
    if (showPrivacyDialog) {
        AlertDialog(
            onDismissRequest = { showPrivacyDialog = false },
            title = { Text("سياسة الخصوصية وحذف البيانات") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("• جميع الحسابات والمعالجات تتم على معالج هاتفك محلياً.", fontSize = 13.sp)
                    Text("• لا يتم إرسال أي نصوص شاشة أو بيانات ركاب إلى خوادم خارجية.", fontSize = 13.sp)
                    Text("• الخادم يتلقى فقط رقم ترخيص الاشتراك للتحقق من الصلاحية عند الطلب.", fontSize = 13.sp)
                    Text("• يمكنك حذف جميع بياناتك المخزنة محلياً (المناطق، السجل، القواعد) بمسح بيانات التطبيق أو الضغط أدناه.", fontSize = 13.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = { showPrivacyDialog = false }) { Text("إغلاق") }
            }
        )
    }
}

@Composable
private fun MenuItemRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = AytosBlue,
            modifier = Modifier.size(24.dp)
        )
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = subtitle,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.secondary
            )
        }
        Icon(
            imageVector = Icons.Default.ChevronLeft,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.secondary,
            modifier = Modifier.size(20.dp)
        )
    }
}

@Composable
private fun SocialChannelButton(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp),
        modifier = Modifier.clickable { onClick() }
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(AytosBlueLightBg),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = icon, contentDescription = title, tint = AytosBlue, modifier = Modifier.size(22.dp))
        }
        Text(text = title, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
private fun ReportProblemDialog(
    onDismiss: () -> Unit,
    onSubmit: (category: String, desc: String) -> Unit
) {
    var category by remember { mutableStateOf("قراءة السعر غير صحيحة") }
    var desc by remember { mutableStateOf("") }
    val categories = listOf("قراءة السعر غير صحيحة", "مسافة الاستلام غير دقيقة", "النافذة العايمة لم تظهر", "تنبيه الفرصة لم يرن", "تطبيق إن درايف لم يُقرأ", "أخرى")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إبلاغ عن مشكلة في قراءة كارت") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "سيتم إرفاق أرقام الحسابات والنتائج فقط لحل المشكلة دون نصوص أو بيانات ركاب.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.secondary
                )

                var expandedCat by remember { mutableStateOf(false) }
                Box {
                    OutlinedButton(
                        onClick = { expandedCat = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(category, maxLines = 1)
                    }
                    DropdownMenu(
                        expanded = expandedCat,
                        onDismissRequest = { expandedCat = false }
                    ) {
                        categories.forEach { cat ->
                            DropdownMenuItem(
                                text = { Text(cat) },
                                onClick = {
                                    category = cat
                                    expandedCat = false
                                }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = desc,
                    onValueChange = { desc = it },
                    label = { Text("وصف المشكلة (مثلاً: السعر كان 120 ج قرأه 20)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    minLines = 3
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSubmit(category, desc) },
                colors = ButtonDefaults.buttonColors(containerColor = AytosBlue)
            ) {
                Text("إرسال البلاغ")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}

@Composable
private fun LicenseActivationDialog(
    currentLicense: LicenseInfo,
    onDismiss: () -> Unit,
    onActivate: (String) -> Unit
) {
    var licenseKey by remember { mutableStateOf("") }
    var discountCode by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("الاشتراك وتفعيل الرخصة") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Surface(
                    color = AytosBlueLightBg,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(text = "اشتراك Google Play الشهري:", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = AytosBlueDark)
                        Text(text = "99.00 ج.م / شهر (أول 7 أيام مجاناً، إلغاء في أي وقت من متجر Play)", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                    }
                }

                OutlinedTextField(
                    value = licenseKey,
                    onValueChange = { licenseKey = it },
                    label = { Text("أو أدخل مفتاح الترخيص (License Key)") },
                    placeholder = { Text("AYTOS-PRO-XXXX-XXXX") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    singleLine = true
                )

                OutlinedTextField(
                    value = discountCode,
                    onValueChange = { discountCode = it },
                    label = { Text("كود خصم الكباتن (إن وجد)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onActivate(licenseKey) },
                enabled = licenseKey.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = AytosBlue)
            ) {
                Text("تفعيل")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إغلاق") }
        }
    )
}

private fun openUrl(context: android.content.Context, url: String) {
    try {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        context.startActivity(intent)
    } catch (_: Exception) {}
}
