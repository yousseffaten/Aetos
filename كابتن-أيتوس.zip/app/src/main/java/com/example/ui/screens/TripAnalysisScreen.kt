package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.AytosJudgmentEngine
import com.example.model.*
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun TripAnalysisScreen(
    driverRules: DriverRules,
    licenseInfo: LicenseInfo,
    latestJudgment: JudgmentResult?,
    onUseAnalysisCredit: () -> Boolean,
    onNavigateToSubscribe: () -> Unit
) {
    var fareInput by remember { mutableStateOf(latestJudgment?.grossFare?.toInt()?.toString() ?: "85") }
    var pickupInput by remember { mutableStateOf(latestJudgment?.order?.pickupDistanceKm?.toString() ?: "1.5") }
    var tripInput by remember { mutableStateOf(latestJudgment?.order?.tripDistanceKm?.toString() ?: "12.0") }
    var selectedApp by remember { mutableStateOf(latestJudgment?.order?.app ?: SupportedApp.UBER) }
    var ratingInput by remember { mutableStateOf(latestJudgment?.order?.passengerRating?.toString() ?: "4.85") }

    val judgmentEngine = remember { AytosJudgmentEngine() }
    var currentAnalysis by remember { mutableStateOf<JudgmentResult?>(latestJudgment) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    fun calculate() {
        val hasCredit = onUseAnalysisCredit()
        if (!hasCredit) {
            errorMessage = "لقد استنفدت رصيد التحليل التفصيلي المجاني لليوم (تحليلين يومياً). يمكنك ترقية حسابك للاشتراك غير المحدود."
            return
        }

        val fare = fareInput.toDoubleOrNull() ?: 0.0
        val pickup = pickupInput.toDoubleOrNull() ?: 0.0
        val trip = tripInput.toDoubleOrNull() ?: 0.0
        val rating = ratingInput.toDoubleOrNull() ?: 4.8

        val order = OrderDetails(
            app = selectedApp,
            fare = fare,
            pickupDistanceKm = pickup,
            tripDistanceKm = trip,
            passengerRating = rating,
            stopsCount = 1
        )
        currentAnalysis = judgmentEngine.evaluate(order, driverRules)
        errorMessage = null
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        SectionHeader(
            title = "التحليل التفصيلي للرحلة",
            subtitle = "تشريح كامل للمسافات وعمولة التطبيق وتكلفة البنزين وصافي الأرباح."
        )

        // License & Credits Status Banner
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = if (licenseInfo.tier == LicenseTier.FREE_BASIC) MaterialTheme.colorScheme.surfaceVariant else AytosGreenBg,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "الخطة الحالية: ${licenseInfo.tier.labelArabic}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = if (licenseInfo.tier == LicenseTier.FREE_BASIC) {
                            "المتبقي اليوم: ${licenseInfo.dailyDetailedAnalysisLeft} تحليلات تفصيلية (تتجدد غداً)"
                        } else {
                            "تحليل تفصيلي غير محدود ✓"
                        },
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }

                if (licenseInfo.tier == LicenseTier.FREE_BASIC) {
                    TextButton(onClick = onNavigateToSubscribe) {
                        Text("ترقية للخطة الشهرية", fontSize = 12.sp, color = AytosBlue)
                    }
                }
            }
        }

        // Input Card
        IosCard {
            Text(
                text = "بيانات المشوار المراد تحليله:",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(10.dp))

            // App Selector
            IosSegmentedControl(
                options = listOf("أوبر (25%)", "ديدي (22%)", "إن درايف (12%)"),
                selectedIndex = when (selectedApp) {
                    SupportedApp.UBER -> 0
                    SupportedApp.DIDI -> 1
                    SupportedApp.INDRIVER -> 2
                },
                onSelectIndex = { index ->
                    selectedApp = when (index) {
                        0 -> SupportedApp.UBER
                        1 -> SupportedApp.DIDI
                        else -> SupportedApp.INDRIVER
                    }
                }
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = fareInput,
                    onValueChange = { fareInput = it },
                    label = { Text("السعر (ج.م)") },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp),
                    singleLine = true
                )

                OutlinedTextField(
                    value = pickupInput,
                    onValueChange = { pickupInput = it },
                    label = { Text("الاستلام (كم)") },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp),
                    singleLine = true
                )

                OutlinedTextField(
                    value = tripInput,
                    onValueChange = { tripInput = it },
                    label = { Text("الرحلة (كم)") },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp),
                    singleLine = true
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = ratingInput,
                onValueChange = { ratingInput = it },
                label = { Text("تقييم الراكب ★ (اختياري)") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(12.dp))

            IosPrimaryButton(
                text = "احسب التحليل التفصيلي الآن",
                icon = Icons.Default.Analytics,
                onClick = { calculate() },
                testTag = "run_analysis_button"
            )
        }

        errorMessage?.let { msg ->
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = AytosRedBg,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = AytosRed)
                    Text(text = msg, fontSize = 12.sp, color = AytosRed, lineHeight = 16.sp)
                }
            }
        }

        // Analysis Results Card
        currentAnalysis?.let { analysis ->
            val verdictColor = Color(analysis.verdict.primaryColorHex)
            val verdictBg = Color(analysis.verdict.bgColorHex)

            IosCard(
                borderColor = verdictColor.copy(alpha = 0.6f)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "الحكم النهائي للطلب:",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(verdictBg)
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = analysis.verdict.labelArabic,
                            color = verdictColor,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Net Profit Hero
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if ((analysis.netProfit ?: 0.0) > 0) AytosGreenBg else AytosRedBg,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(text = "صافي المكسب الفعلي الذي يدخل جيبك:", fontSize = 13.sp, color = IosLightTextSecondary)
                        Text(
                            text = "${String.format("%.1f", analysis.netProfit ?: 0.0)} ج.م",
                            fontSize = 26.sp,
                            fontWeight = FontWeight.Bold,
                            color = if ((analysis.netProfit ?: 0.0) > 0) AytosGreen else AytosRed,
                            fontFamily = InterFont
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Breakdown list
                AnalysisBreakdownRow(
                    title = "الأجرة المعروضة للطلب",
                    amount = "+${analysis.grossFare?.toInt()} ج.م",
                    color = IosLightTextPrimary
                )
                AnalysisBreakdownRow(
                    title = "عمولة تطبيق ${analysis.order.app.titleArabic}",
                    amount = "-${String.format("%.1f", analysis.commissionDeduction)} ج.م",
                    color = AytosRed
                )
                AnalysisBreakdownRow(
                    title = "تقدير استهلاك البنزين (${driverRules.engineSize.labelArabic.take(12)})",
                    amount = "-${String.format("%.1f", analysis.fuelCostEstimate)} ج.م",
                    color = AytosOrange
                )
                AnalysisBreakdownRow(
                    title = "صيانة المسافة (زيت، فرامل، كاوتش)",
                    amount = "-${String.format("%.1f", analysis.maintenanceEstimate)} ج.م",
                    color = AytosGray
                )

                HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))

                AnalysisBreakdownRow(
                    title = "سعر الكيلو الصافي الفعلي",
                    amount = "${String.format("%.2f", analysis.ratePerKm ?: 0.0)} ج.م/كم",
                    color = AytosBlue
                )

                if (analysis.reasons.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(text = "تفاصيل الملاحظات والأسباب:", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    analysis.reasons.forEach { reason ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.padding(vertical = 2.dp)
                        ) {
                            Box(modifier = Modifier.size(6.dp).background(verdictColor, CircleShape))
                            Text(text = reason, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                        }
                    }
                }

                analysis.counterOfferSuggestedFare?.let { counterOffer ->
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = AytosOrangeBg,
                        border = androidx.compose.foundation.BorderStroke(1.dp, AytosOrange),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "اقتراح التفاوض العادل لك:", fontSize = 13.sp, color = AytosOrange, fontWeight = FontWeight.SemiBold)
                            Text(text = "اطلب ${counterOffer.toInt()} ج.م", fontSize = 15.sp, color = AytosOrange, fontWeight = FontWeight.Bold, fontFamily = InterFont)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(30.dp))
    }
}

@Composable
private fun AnalysisBreakdownRow(title: String, amount: String, color: Color) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = title, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
        Text(text = amount, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = color, fontFamily = InterFont)
    }
}
