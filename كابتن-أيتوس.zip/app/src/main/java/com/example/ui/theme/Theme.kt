package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = AytosBlue,
    onPrimary = Color.White,
    primaryContainer = AytosBlueDark,
    onPrimaryContainer = Color.White,
    secondary = IosDarkTextSecondary,
    onSecondary = Color.White,
    background = IosDarkBackground,
    onBackground = IosDarkTextPrimary,
    surface = IosDarkCard,
    onSurface = IosDarkTextPrimary,
    surfaceVariant = IosDarkSurfaceVariant,
    onSurfaceVariant = IosDarkTextSecondary,
    outline = IosDarkBorder
)

private val LightColorScheme = lightColorScheme(
    primary = AytosBlue,
    onPrimary = Color.White,
    primaryContainer = AytosBlueLightBg,
    onPrimaryContainer = AytosBlueDark,
    secondary = IosLightTextSecondary,
    onSecondary = Color.White,
    background = IosLightBackground,
    onBackground = IosLightTextPrimary,
    surface = IosLightCard,
    onSurface = IosLightTextPrimary,
    surfaceVariant = IosLightSurfaceVariant,
    onSurfaceVariant = IosLightTextSecondary,
    outline = IosLightBorder
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
