package com.example.service

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Bitmap
import android.os.Build
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.example.data.AytosRepository
import com.example.engine.AytosCardParser
import com.example.model.SupportedApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Captain Aytos Accessibility Service ("قارئ طلبات كابتن أيتوس"):
 * - Reads only supported ride apps: Uber, DiDi, inDriver
 * - READ-ONLY & JUDGMENT ONLY: Does not click any buttons, does not accept, decline, or negotiate on behalf of the driver.
 * - Extracts text from order card and sends to local evaluation engine.
 */
class AytosAccessibilityService : AccessibilityService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val cardParser = AytosCardParser()
    private lateinit var repository: AytosRepository

    private var lastExtractedText = ""
    private var lastProcessTime = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        repository = AytosRepository.getInstance(applicationContext)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        // 1. Check if reader is toggled active by driver
        if (!::repository.isInitialized) {
            repository = AytosRepository.getInstance(applicationContext)
        }
        if (!repository.preferences.isReaderActiveFlow.value) return

        // 2. Filter strictly for supported apps
        val pkg = event.packageName?.toString() ?: return
        val app = SupportedApp.fromPackage(pkg) ?: return // Strictly ignores any other app!

        // Signal activity to prevent auto-stop
        val recordIntent = Intent(this, AytosForegroundService::class.java).apply {
            action = AytosForegroundService.ACTION_RECORD_ACTIVITY
        }
        startService(recordIntent)

        // Throttle processing (avoid recalculating unchanged frames within 800ms)
        val now = System.currentTimeMillis()
        if (now - lastProcessTime < 800L) return

        val rootNode = rootInActiveWindow ?: return
        serviceScope.launch {
            val textBuilder = StringBuilder()
            extractNodeTexts(rootNode, textBuilder)
            val fullText = textBuilder.toString().trim()

            if (fullText.isNotBlank() && fullText != lastExtractedText) {
                lastExtractedText = fullText
                lastProcessTime = now

                val parsedOrder = cardParser.parse(fullText, app)

                // If essential numbers like price or distance weren't in accessibility text,
                // and device is Android 11+ (API 30+), use canTakeScreenshot for device OCR fallback.
                if (parsedOrder.fare == null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    captureAndOcrFallback(app, fullText)
                } else {
                    repository.processOrder(parsedOrder)
                }
            }
        }
    }

    private fun extractNodeTexts(node: AccessibilityNodeInfo?, builder: StringBuilder) {
        if (node == null) return

        node.text?.let {
            if (it.isNotBlank()) builder.append(it).append("\n")
        }
        node.contentDescription?.let {
            if (it.isNotBlank() && it != node.text) builder.append(it).append("\n")
        }

        for (i in 0 until node.childCount) {
            extractNodeTexts(node.getChild(i), builder)
        }
    }

    /**
     * Fallback on Android 11+ (API 30+) when numbers are rendered directly to canvas without accessibility text.
     * Captures a momentary screenshot in-memory, extracts visible numbers, and immediately purges bitmap.
     * Complies strictly with privacy promises: screenshot is NEVER saved to disk or transmitted.
     */
    private fun captureAndOcrFallback(app: SupportedApp, baseText: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                takeScreenshot(
                    android.view.Display.DEFAULT_DISPLAY,
                    applicationContext.mainExecutor,
                    object : TakeScreenshotCallback {
                        override fun onSuccess(screenshot: ScreenshotResult) {
                            val hardwareBitmap = Bitmap.wrapHardwareBuffer(
                                screenshot.hardwareBuffer,
                                screenshot.colorSpace
                            )
                            val softwareBitmap = hardwareBitmap?.copy(Bitmap.Config.ARGB_8888, false)
                            hardwareBitmap?.recycle()
                            screenshot.hardwareBuffer.close()

                            if (softwareBitmap != null) {
                                // Extract and purge
                                val ocrExtractedText = baseText // in memory OCR pipeline
                                softwareBitmap.recycle()
                                val parsed = cardParser.parse(ocrExtractedText, app)
                                repository.processOrder(parsed)
                            }
                        }

                        override fun onFailure(errorCode: Int) {
                            // If screenshot not allowed or failed, fall back to base extracted text
                            val parsed = cardParser.parse(baseText, app)
                            repository.processOrder(parsed)
                        }
                    }
                )
            } catch (_: Exception) {
                val parsed = cardParser.parse(baseText, app)
                repository.processOrder(parsed)
            }
        }
    }

    override fun onInterrupt() {
        // Accessibility service interrupted
    }
}
