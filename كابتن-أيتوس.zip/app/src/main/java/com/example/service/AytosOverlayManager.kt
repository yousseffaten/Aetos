package com.example.service

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.compose.ui.platform.ComposeView
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.example.data.AytosRepository
import com.example.model.JudgmentResult
import com.example.ui.components.FloatingJudgmentOverlayContent
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.collectLatest

/**
 * Manages the SYSTEM_ALERT_WINDOW floating pill/card above ride-hailing maps.
 * - Draggable across screen
 * - Collapsible into compact pill
 * - Expandable into full breakdown
 * - Configurable transparency & scale
 */
class AytosOverlayManager(private val context: Context) {

    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val repository = AytosRepository.getInstance(context)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private var overlayView: View? = null
    private var params: WindowManager.LayoutParams? = null

    private var isExpanded = true
    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f

    fun startListening() {
        scope.launch {
            repository.latestJudgment.collectLatest { judgment ->
                if (judgment != null && repository.isOverlayVisible.value) {
                    showOverlay(judgment)
                } else {
                    hideOverlay()
                }
            }
        }

        scope.launch {
            repository.isOverlayVisible.collectLatest { isVisible ->
                if (!isVisible) {
                    hideOverlay()
                } else {
                    repository.latestJudgment.value?.let { showOverlay(it) }
                }
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    fun showOverlay(judgment: JudgmentResult) {
        if (!Settings.canDrawOverlays(context)) {
            return
        }

        if (overlayView == null) {
            val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE
            }

            params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                layoutType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = 30
                y = 180
            }

            val composeView = ComposeView(context).apply {
                setContent {
                    MyApplicationTheme {
                        FloatingJudgmentOverlayContent(
                            judgment = judgment,
                            isExpanded = isExpanded,
                            opacity = repository.preferences.rulesFlow.value.overlayOpacity,
                            scale = repository.preferences.rulesFlow.value.overlayScale,
                            onToggleExpand = {
                                isExpanded = !isExpanded
                                updateOverlayContent(judgment)
                            },
                            onDismiss = {
                                repository.dismissOverlay()
                            }
                        )
                    }
                }

                setOnTouchListener { _, event ->
                    when (event.action) {
                        MotionEvent.ACTION_DOWN -> {
                            initialX = params?.x ?: 0
                            initialY = params?.y ?: 0
                            initialTouchX = event.rawX
                            initialTouchY = event.rawY
                            true
                        }
                        MotionEvent.ACTION_MOVE -> {
                            params?.let { p ->
                                p.x = initialX + (event.rawX - initialTouchX).toInt()
                                p.y = initialY + (event.rawY - initialTouchY).toInt()
                                windowManager.updateViewLayout(overlayView, p)
                            }
                            true
                        }
                        else -> false
                    }
                }
            }

            overlayView = composeView
            try {
                windowManager.addView(overlayView, params)
            } catch (_: Exception) {}
        } else {
            updateOverlayContent(judgment)
        }
    }

    private fun updateOverlayContent(judgment: JudgmentResult) {
        val composeView = overlayView as? ComposeView ?: return
        composeView.setContent {
            MyApplicationTheme {
                FloatingJudgmentOverlayContent(
                    judgment = judgment,
                    isExpanded = isExpanded,
                    opacity = repository.preferences.rulesFlow.value.overlayOpacity,
                    scale = repository.preferences.rulesFlow.value.overlayScale,
                    onToggleExpand = {
                        isExpanded = !isExpanded
                        updateOverlayContent(judgment)
                    },
                    onDismiss = {
                        repository.dismissOverlay()
                    }
                )
            }
        }
    }

    fun hideOverlay() {
        overlayView?.let { view ->
            try {
                windowManager.removeView(view)
            } catch (_: Exception) {}
            overlayView = null
        }
    }

    fun release() {
        hideOverlay()
        scope.cancel()
    }
}
