package com.example.model

enum class ZoneType(val labelArabic: String) {
    PREFERRED("مفضلة (حبيبي فيها الشغل)"),
    AVOIDED("متجنّبة (زحمة / طرق وعرة / بطيئة)")
}

data class ZoneItem(
    val id: Long = 0,
    val name: String,
    val governorate: String,
    val type: ZoneType,
    val notes: String = "",
    val radiusKm: Double = 3.0
)

data class ShiftSummary(
    val totalOrdersScanned: Int = 0,
    val acceptedOrdersCount: Int = 0,
    val totalEstimatedNetProfit: Double = 0.0,
    val avoidedCostSaved: Double = 0.0
)

enum class LicenseTier(val labelArabic: String) {
    TRIAL("تجربة مجانية (7 أيام)"),
    FREE_BASIC("خطة مجانية (حكم غير محدود + تحليلين يومياً)"),
    PRO_MONTHLY("اشتراك شهري كامل"),
    PRO_LIFETIME("رخصة مفعلة")
}

data class LicenseInfo(
    val tier: LicenseTier = LicenseTier.TRIAL,
    val trialDaysRemaining: Int = 7,
    val dailyDetailedAnalysisLeft: Int = 2,
    val licenseKey: String = "",
    val canTransferDeviceThisMonth: Boolean = true,
    val expiresAtTimestamp: Long = System.currentTimeMillis() + (7L * 24 * 60 * 60 * 1000)
)

data class DriverProfile(
    val firstName: String = "كابتن",
    val lastName: String = "محمد",
    val phoneWithCountryCode: String = "+201012345678",
    val governorate: String = "القاهرة",
    val country: String = "مصر",
    val currency: String = "ج.م"
)

data class ProblemReport(
    val id: Long = 0,
    val category: String,
    val description: String,
    val attachedMetricsJson: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isSentToServer: Boolean = false
)
