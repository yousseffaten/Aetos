package com.example

import android.app.Application
import com.example.data.AytosRepository
import com.example.service.AytosForegroundService
import com.example.service.AytosOverlayManager

class AytosApplication : Application() {

    lateinit var overlayManager: AytosOverlayManager
        private set

    override fun onCreate() {
        super.onCreate()

        // Initialize Repository
        AytosRepository.getInstance(this)

        // Initialize Overlay Manager
        overlayManager = AytosOverlayManager(this)
        overlayManager.startListening()

        // Start Persistent Foreground Service
        AytosForegroundService.start(this)
    }
}
